﻿namespace NadekoBot.Modules.Games.Common
{
    public class TypingArticle
    {
        public string Title { get; set; }
        public string Text { get; set; }
    }
}
