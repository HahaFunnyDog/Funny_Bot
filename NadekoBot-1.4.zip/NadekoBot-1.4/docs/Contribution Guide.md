### How to contribute

1. Make Pull Requests to the [**dev BRANCH**](https://github.com/Kwoth/NadekoBot/tree/dev).
2. Keep 1 Pull Request to a single feature.
3. Explain what you did in the PR message.

Thanks for all your help ^_^
